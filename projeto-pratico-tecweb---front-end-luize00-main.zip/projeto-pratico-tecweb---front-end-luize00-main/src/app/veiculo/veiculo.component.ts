import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { VeiculoService } from '../veiculo.service';

//????????????????????????//
export class Veiculo {
  id: number;
  marca: string;
  modelo: string;
  status: "Disponivel";
}

@Component({
  selector: 'app-veiculo',
  templateUrl: './veiculo.component.html',
  styleUrls: ['./veiculo.component.css']
})
export class VeiculoComponent implements OnInit {

  displayedColumns: string[] = ['id','marca','modelo','status', 'acoes'];
  dataSource = new MatTableDataSource<Veiculo>();

  constructor(private service: VeiculoService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.service.getVeiculos().subscribe(veiculos => this.dataSource.data = veiculos);
  }

  openNewDialog(): void {
    const dialogRef =this.dialog.open(MngVeiculoDialog,{
      width: '750px',
      data: new Veiculo()
    });

    dialogRef.afterClosed().subscribe(veiculo => {
      this.service.adicionar(veiculo).subscribe(veiculoId => {
        this.service.getVeiculo(veiculoId).subscribe(newVeiculo =>{
          this.dataSource.data = this.dataSource.data.concat(newVeiculo);
        });
      });
    });
  }

  openEditDialog(veiculo: Veiculo): void {
    const dialogRef =this.dialog.open(MngVeiculoDialog,{
      width: '750px',
      data: veiculo
    });

    dialogRef.afterClosed().subscribe(veiculo => {
      this.service.editar(veiculo).subscribe(_ => {
        this.dataSource.data= this.dataSource.data.map(oldVeiculo =>{
          if (oldVeiculo.id == veiculo.id) return veiculo;
        });
      });
    })
  }

  excluir(veiculo: Veiculo): void{
    this.service.remover(veiculo.id).subscribe(_ => {
      this.dataSource.data = this.dataSource.data.filter(oldVeiculo => oldVeiculo.id != veiculo.id);
    })
  }

}

@Component({
  selector: 'dialog-mng-veiculo',
  templateUrl: 'dialog-mng-veiculo.html'
})

export class MngVeiculoDialog{

  constructor(public dialogRef: MatDialogRef<MngVeiculoDialog>,
    @Inject(MAT_DIALOG_DATA) public data: Veiculo) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}