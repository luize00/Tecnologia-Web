import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AluguelComponent } from './aluguel/aluguel.component';
import { VeiculoComponent } from './veiculo/veiculo.component';

const routes: Routes = [
  { path: 'veiculo', component: VeiculoComponent},
  { path: 'aluguel', component: AluguelComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
