import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Veiculo } from './veiculo/veiculo.component'

@Injectable({
  providedIn: 'root'
})
export class VeiculoService {

  constructor(private http: HttpClient) { }

  getVeiculos(): Observable<Veiculo[]> {
    return this.http.get<Veiculo[]>("http://localhost:3000/veiculo");
  }

  getVeiculo(veiculoId: number): Observable<Veiculo> {
    return this.http.get<Veiculo>("http://localhost:3000/veiculo/" + veiculoId);
  }

  adicionar(veiculo: Veiculo): Observable<any> {
    return this.http.post("http://localhost:3000/veiculo", veiculo);
  }

  editar(veiculo: Veiculo): Observable<any> {
    return this.http.put("http://localhost:3000/veiculo/" + veiculo.id, veiculo);
  }

  remover(veiculoId: number): Observable<any> {
    return this.http.delete("http://localhost:3000/veiculo/" + veiculoId);
  }


}
