import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aluguel',
  templateUrl: './aluguel.component.html',
  styleUrls: ['./aluguel.component.css']
})
export class AluguelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
